Comprehensivelly refactor the application completely. The application must not be the Professional Help Desk & Ticket Management System. It has to be the application to get current review of high-demand and high-value sports events entry tickets (especially for Manchester United team sports events), review those are availlable and when. Then administrator or agent have the option to choose some of them to obtain and buy them by very frequent scrapping during time set and according various implemented platforms. The database has 1000+ fake random scraping users whose have no access to the application, but they are used for frequent scraping to obtain requested high-demand and high-value sports events entry tickets.

Comprehensive Sports Event Ticket Scraping & Monitoring System

The application must be able to:

1. Monitor ticket availability for high-demand sports events (e.g., Manchester United matches, UEFA Champions League matches, etc.)
2. Track ticket prices and availability over time
3. Set up alerts for specific events or teams
4. Purchase tickets automatically when they become available
5. Manage multiple accounts for ticket purchases
6. Handle payment processing and transaction management
7. Generate reports and analytics on ticket purchases
8. Provide user-friendly interfaces for both administrators and agents
9. Ensure compliance with legal and regulatory requirements
10. Offer a secure and reliable platform for ticket purchases

