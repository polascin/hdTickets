<img src="{{ asset('assets/images/hdTicketsLogo.png') }}" alt="HD Tickets Logo" {{ $attributes }}>
